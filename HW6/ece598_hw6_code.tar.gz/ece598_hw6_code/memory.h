int memory_init(unsigned long memory_total,unsigned long memory_kernel);
void *memory_allocate(int size);
