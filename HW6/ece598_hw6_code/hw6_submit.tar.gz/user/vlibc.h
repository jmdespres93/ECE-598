int putchar(int ch);
int getchar(void);
int printf(char *string,...);
