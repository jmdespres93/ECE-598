extern uint32_t tick_counter;
int timer_init(void);
