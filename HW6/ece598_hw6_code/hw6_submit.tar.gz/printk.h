int printk(char *string,...);

