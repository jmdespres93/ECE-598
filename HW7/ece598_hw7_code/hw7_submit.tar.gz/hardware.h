#define RPI_UNKNOWN		0
#define RPI_MODEL_A		1
#define RPI_MODEL_B		2
#define RPI_MODEL_APLUS		3
#define RPI_MODEL_BPLUS		4
#define RPI_MODEL_B2		5
#define RPI_COMPUTE_NODE	6

extern int hardware_type;
