int console_write(const void *buf, size_t count);
int console_read(const void *buf, size_t count);
