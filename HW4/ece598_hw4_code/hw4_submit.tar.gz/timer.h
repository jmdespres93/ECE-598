int timer_init(void);
