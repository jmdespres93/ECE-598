int printk(char *string,...);
void nyan (void);
